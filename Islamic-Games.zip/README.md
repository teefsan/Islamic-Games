# Islamic-Games (static web)
ไฟล์เวอร์ชันที่สร้างให้ครูพร้อมอัปโหลดขึ้น GitHub Pages

**สิ่งที่ทำให้แล้ว**
- ธีม: ฟ้าอ่อน + น้ำเงินเข้ม (อ่านง่ายสำหรับเด็กประถม)
- ข้อความต้อนรับ: السلام عليكم ورحمة الله وبركاته
- ปุ่มเริ่มเกม: أنا مستعد
- ดึงคำถามจาก Google Apps Script (GET ?action=getQuestions)
- ส่งผลลัพธ์ไป Google Apps Script (POST)
- Leaderboard: พยายามเรียก GET ?action=getStats (ถ้า Apps Script มีให้) — ถ้าไม่มีก็ยังเล่นได้และสถิติจะถูกบันทึกใน Sheet

**การติดตั้งขึ้น GitHub Pages:**
1. เข้า repo ของคุณ (https://github.com/teefsan/Islamic-Games)
2. Upload ไฟล์ในโฟลเดอร์นี้ (index.html, style.css, script.js, README.md) ไปยัง root ของ repo
3. ไปที่ Settings → Pages → Source: เลือก Branch `main` และ Folder `/ (root)` → Save
4. รอ 1-2 นาที แล้วเปิด https://<your-github-username>.github.io/Islamic-Games/

**หมายเหตุสำคัญเกี่ยวกับ Leaderboard**
- ฟีเจกต์ Apps Script ต้องมี endpoint `?action=getStats` ที่ส่ง JSON รายการสถิติ ถ้าไม่มี leaderboard จะแสดงข้อความว่าไม่พร้อมใช้งาน
- ถ้ต้องการ ผมช่วยให้โค้ด Apps Script เพิ่ม endpoint getStats ได้ (ส่งโค้ดให้คัดวาง)

**ถ้ามีปัญหา เปิดหน้า Console (F12) และเก็บ screenshot หรือ copy error แล้วส่งมาให้ผม ผมจะแก้ให้ครับ.**

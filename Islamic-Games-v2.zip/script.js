// script.js - complete game logic (uses API_URL provided)
const API_URL = "https://script.google.com/macros/s/AKfycbyT_zCugWP6X7PlTsVXV-6_5viHDC1VnlAlL812F0xrarZqx3eki_xoFl3lrp_EDchc/exec";

let questions = [];
let current = 0, score = 0, attempts = 0, timer = 0, timerInterval = null;
let playerName = "", playerClass = "", startTime = 0;

// DOM refs
const startScreen = document.getElementById('startScreen');
const gameScreen = document.getElementById('gameScreen');
const endScreen = document.getElementById('endScreen');
const startBtn = document.getElementById('startBtn');
const fullnameInput = document.getElementById('fullname');
const classroomInput = document.getElementById('classroom');
const qIndexEl = document.getElementById('qIndex');
const qTotalEl = document.getElementById('qTotal');
const questionText = document.getElementById('questionText');
const choicesDiv = document.getElementById('choices');
const feedback = document.getElementById('feedback');
const scoreEl = document.getElementById('score');
const timerEl = document.getElementById('timer');
const quitBtn = document.getElementById('quitBtn');
const resultBox = document.getElementById('resultBox');
const leaderboardDiv = document.getElementById('leaderboard');
const playAgainBtn = document.getElementById('playAgainBtn');

// simple sounds
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playTone(freq,d=0.12){const o=audioCtx.createOscillator();const g=audioCtx.createGain();o.type='sine';o.frequency.value=freq;o.connect(g);g.connect(audioCtx.destination);g.gain.value=0.0001;g.gain.exponentialRampToValueAtTime(0.12,audioCtx.currentTime+0.01);o.start();setTimeout(()=>{g.gain.exponentialRampToValueAtTime(0.0001,audioCtx.currentTime+0.04);o.stop();},d*1000);}
function playCorrect(){playTone(880,0.14);setTimeout(()=>playTone(1100,0.08),80);}
function playWrong(){playTone(240,0.12);}

// fireworks canvas
const canvas = document.getElementById('fireworks');
const ctx = canvas.getContext('2d');
function burst(){canvas.width=innerWidth;canvas.height=innerHeight;let ps=[];const colors=['#FFD166','#F0A500','#FFC857','#FFB4A2','#FF7B00'];for(let i=0;i<80;i++){ps.push({x:canvas.width/2,y:canvas.height/3,vx:(Math.random()-0.5)*6,vy:(Math.random()-0.8)*6,r:Math.random()*3+1,color:colors[Math.floor(Math.random()*colors.length)],a:1})}function d(){ctx.clearRect(0,0,canvas.width,canvas.height);ps.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.vy+=0.04;p.a-=0.012;ctx.globalAlpha=Math.max(0,p.a);ctx.beginPath();ctx.fillStyle=p.color;ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fill()});ctx.globalAlpha=1;if(ps.some(p=>p.a>0))requestAnimationFrame(d);else ctx.clearRect(0,0,canvas.width,canvas.height);}d();}

// fetch questions
async function loadQuestions(){
  try{
    const res = await fetch(API_URL + "?action=getQuestions");
    if(!res.ok) throw new Error('fetch failed');
    const data = await res.json();
    if(Array.isArray(data) && data.length){questions = data; qTotalEl.innerText = questions.length; return true;}
    else {questions = []; qTotalEl.innerText = 0; return false;}
  }catch(e){console.warn('loadQuestions error',e); return false;}
}

// UI functions
async function startGame(){
  playerName = fullnameInput.value.trim(); playerClass = classroomInput.value.trim();
  if(!playerName || !playerClass){alert('กรุณากรอกชื่อและชั้นก่อนเริ่ม');return;}
  startScreen.classList.add('hidden'); gameScreen.classList.remove('hidden');
  score = 0; attempts = 0; timer = 0; current = 0; startTime = Date.now();
  scoreEl.innerText = score; timerEl.innerText = timer; feedback.innerText = '';
  const ok = await loadQuestions();
  if(!ok){alert('ไม่พบคำถามจาก server — กรุณาตรวจสอบ Questions sheet ใน Google Sheets');}
  timerInterval = setInterval(()=>{timer++; timerEl.innerText = timer;},1000);
  renderQuestion();
}

function renderQuestion(){
  if(current >= questions.length){finishGame(); return;}
  const q = questions[current];
  qIndexEl.innerText = current+1; questionText.innerText = q.q;
  choicesDiv.innerHTML = '';
  q.choices.forEach((c,i)=>{
    const btn = document.createElement('button');
    btn.className = 'choice-btn';
    btn.innerText = c;
    btn.onclick = ()=> choose(i);
    choicesDiv.appendChild(btn);
  });
}

function choose(i){
  attempts++; feedback.innerText = '';
  const q = questions[current];
  if(i === q.answer){
    score++; scoreEl.innerText = score; feedback.innerText = '🎉 ถูกต้องเลยคร้าบ! 🎉'; playCorrect(); burst();
    setTimeout(()=>{current++; feedback.innerText=''; renderQuestion();},900);
  } else {
    feedback.innerText = 'ไม่เป็นไร ค่อยลองใหม่นะจ๊ะ 😊'; playWrong();
  }
}

quitBtn.addEventListener('click', ()=>{ if(confirm('ยุติการเล่นและบันทึกผลใช่หรือไม่?')) finishGame(); });

async function finishGame(){
  clearInterval(timerInterval);
  gameScreen.classList.add('hidden'); endScreen.classList.remove('hidden');
  const timeSec = Math.floor((Date.now() - startTime)/1000);
  resultBox.innerHTML = "<div>ชื่อ: <strong>" + escapeHtml(playerName) + "</strong> (ชั้น " + escapeHtml(playerClass) + ")</div>"
    + "<div>คะแนน: <strong>" + score + "/" + questions.length + "</strong></div>"
    + "<div>พยายาม: <strong>" + attempts + "</strong> ครั้ง</div>"
    + "<div>เวลา: <strong>" + timeSec + "</strong> วินาที</div>";
  // send to server (fire-and-forget)
  try{
    await fetch(API_URL, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      name: playerName, class: playerClass, score: score, attempts: attempts, time: timeSec, plays: 1, userAgent: navigator.userAgent
    })});
  }catch(e){ console.warn('submit error', e); }
  // try load leaderboard (requires server to implement getStats)
  try{
    const r = await fetch(API_URL + "?action=getStats");
    if(r.ok){const stats = await r.json(); renderLeaderboard(stats);} else {leaderboardDiv.innerHTML = '<div class=\"tiny\">Leaderboard ไม่พร้อมใช้งาน (getStats ไม่ตอบ) </div>';}
  }catch(e){leaderboardDiv.innerHTML = '<div class=\"tiny\">Leaderboard ไม่พร้อมใช้งาน</div>';}
}

function renderLeaderboard(stats){
  if(!Array.isArray(stats) || stats.length===0){leaderboardDiv.innerHTML='<div class=\"tiny\">ยังไม่มีสถิติ</div>'; return;}
  stats.sort((a,b)=> b.score - a.score || a.time - b.time);
  leaderboardDiv.innerHTML = '';
  stats.slice(0,50).forEach(s=>{
    const div = document.createElement('div'); div.className='leader-row';
    div.innerHTML = '<div>' + escapeHtml(s.name) + ' (' + escapeHtml(s.class) + ')</div><div>' + s.score + ' • ' + s.time + 's</div>';
    leaderboardDiv.appendChild(div);
  });
}

playAgainBtn.addEventListener('click', ()=>{ location.reload(); });

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[m];}); }

// attach start btn
startBtn.addEventListener('click', startGame);

// preload: set qTotal to 0
qTotalEl.innerText = '0';

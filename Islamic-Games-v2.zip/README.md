# Islamic-Games (ready-to-deploy)
ไฟล์ชุดนี้เป็นเกมตอบคำถามสำหรับเด็กประถม (ธีมฟ้าอ่อน + น้ำเงินเข้ม) พร้อมเชื่อม Google Sheets ผ่าน Google Apps Script.

**วิธีใช้สั้น ๆ**
1. Upload ทั้งหมด (index.html, game.html, style.css, script.js, README.md) ไปไว้ที่ root ของ repo `Islamic-Games`
2. ตั้ง GitHub Pages: Settings -> Pages -> Deploy from a branch -> Branch: main, Folder: / (root)
3. รอ 1-2 นาที แล้วเปิด https://<your-username>.github.io/Islamic-Games/game.html

**หมายเหตุ:** API_URL ใน script.js ตั้งค่าไปที่:
https://script.google.com/macros/s/AKfycbyT_zCugWP6X7PlTsVXV-6_5viHDC1VnlAlL812F0xrarZqx3eki_xoFl3lrp_EDchc/exec

**Leaderboard:** หากต้องการให้ Leaderboard แสดงผล ให้เพิ่ม endpoint `?action=getStats` ใน Google Apps Script (ผมส่งโค้ดให้ได้ถ้าต้องการ)
